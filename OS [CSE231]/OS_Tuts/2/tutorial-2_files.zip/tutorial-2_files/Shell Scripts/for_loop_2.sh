#!/bin/bash
my_list=(one two three four five)
for i in ${my_list[@]}; do echo -n $i | wc -c;
done