#!/bin/bash
echo "User: $USER"
echo "Date: $(date)"
echo "Formatted Date: $(date '+%Y-%m-%d_%H-%M-%S')"