#!/bin/bash
my_list=(1 2 3 4 5) # elements must be space separated
echo $my_list # outputs only the first element
echo ${my_list[@]} # outputs all elements
echo ${my_list[0]} # outputs element at a specific index
echo ${my_list[4]}
echo ${my_list[27]} # outputs nothing