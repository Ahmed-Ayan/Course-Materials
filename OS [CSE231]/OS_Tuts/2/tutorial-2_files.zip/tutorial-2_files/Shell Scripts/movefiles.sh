#!/bin/bash
# Ask user for the source directory
echo "Enter the path for the source directory (dir1):"
read dir1

# Ask user for the destination directory
echo "Enter the path for the destination directory (dir2):"
read dir2

# Check if the source directory exists
if [ ! -d "$dir1" ]; then
  echo "Error: Source directory $dir1 does not exist."
  exit 1
fi

# Check if the destination directory exists
if [ ! -d "$dir2" ]; then
  echo "Destination directory $dir2 does not exist. Creating it now."
  mkdir -p "$dir2"
fi

# Move files from source directory to destination directory
mv "$dir1"/* "$dir2"

# Confirm the move
echo "Files have been moved from $dir1 to $dir2."