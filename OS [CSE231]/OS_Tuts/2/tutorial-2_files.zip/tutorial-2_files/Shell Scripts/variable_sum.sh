#!/bin/bash
num1=78
num2=22
sum=$((num1+num2))
echo "The sum is, $sum"