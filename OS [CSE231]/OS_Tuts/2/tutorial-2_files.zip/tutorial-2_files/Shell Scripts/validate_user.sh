#!/bin/bash
# ${1,,} convert any given string to lowercase
if [ ${1,,} = paarth ]; then echo "Valid user detected. Greetings Paarth!"
elif [ ${1,,} = help ]; then echo "Please enter your username"
else echo "Invalid user detected"
fi