#!/bin/bash
function is_equal(){
	if [ $1 = $2 ]; then echo "Numbers are equal"
	else echo "Numbers are not equal"
	fi
}
is_equal 34 42
is_equal 27 27