#include <stdio.h>

int main() {
    int i = 5;
    while (i != 0) {
        printf("T-minus %d\n", i);
    }
    return 0;
}

