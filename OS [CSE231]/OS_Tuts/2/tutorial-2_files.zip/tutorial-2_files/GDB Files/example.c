// Try using basic GDB commands to navigate through this code, set and delete breakpoints, check out variable values and execution flow etc.
#include <stdio.h>
void bar()
{
    printf("Inside bar\n");
}
void foo() {

    for (int i = 0; i < 10; i++)
    {
        printf("Line %d\n", i);
    }
    bar();
}


int main() {
    
    int x = 10;
    int y = 20;

    x = 12;

    if (x > y) {
        printf("x is greater\n");
    } else {
        printf("y is greater\n");
    }
    
    foo();

    return 0;
}