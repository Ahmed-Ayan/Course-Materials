#include <stdio.h>
#include <string.h>

int main() {
    char *str = NULL; 
    strcpy(str, "hello"); 
    printf("%s\n", str);
    return 0;
}

