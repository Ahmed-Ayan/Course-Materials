import matplotlib.pyplot as plt

# Function to read data from a file
def read_data(file_name):
    with open(file_name, "r") as f:
        data = f.read().strip().split()
    return [float(x) for x in data]

# Read data from files
times_other = read_data("a.txt")  # SCHED_OTHER times
times_rr = read_data("b.txt")    # SCHED_RR times
times_fifo = read_data("c.txt")  # SCHED_FIFO times

# Generate iteration numbers
iterations = list(range(1, 11))  # For 10 iterations

# Plot the data
plt.figure(figsize=(10, 6))

plt.plot(iterations, times_other, label="SCHED_OTHER", marker="o")
plt.plot(iterations, times_rr, label="SCHED_RR", marker="s")
plt.plot(iterations, times_fifo, label="SCHED_FIFO", marker="^")

# Adding labels and title
plt.title("Execution Times for Different Scheduling Policies")
plt.xlabel("Iteration")
plt.ylabel("Execution Time (seconds)")
plt.legend()
plt.grid(True)

# Show the plot
plt.show()

