#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <sched.h>

// Define a constant for converting nanoseconds to seconds
#define value 1000000000L 

// Function to perform counting with SCHED_OTHER scheduling policy
void *countA(void *arg) {
    // Extract priority argument
    int* priority = (int*) arg;
    struct sched_param param;
    param.sched_priority = (int)priority[0];

    // Set scheduling policy to SCHED_OTHER
    pthread_setschedparam(pthread_self(), SCHED_OTHER, &param);

    // Record start time
    struct timespec start, stop; 
    if (clock_gettime(CLOCK_MONOTONIC, &start) == -1) {
        printf("Error occurred with clock_gettime");
    }

    // Perform counting operation
    long long int x;
    for (x = 1; x <= 100000000; x++) { 
    }

    printf("A = %lld\n", x);

    // Record stop time
    if (clock_gettime(CLOCK_MONOTONIC, &stop) == -1) {
        printf("Error occurred with clock_gettime");
    }

    // Calculate elapsed time
    double timeTaken = (stop.tv_sec - start.tv_sec) + 
                       (double)(stop.tv_nsec - start.tv_nsec) / (double)value;
    printf("A time = %lf\n", timeTaken);

    // Log the time to a file
    FILE *fp = fopen("a.txt", "a");
    char buf[1024];
    sprintf(buf, "%lf ", timeTaken);
    fputs(buf, fp);
    fclose(fp);

    return NULL;
}

// Function to perform counting with SCHED_RR scheduling policy
void *countB(void *arg) {
    // Extract priority argument
    int* priority = (int*) arg;
    struct sched_param param;
    param.sched_priority = (int)priority[1];

    // Set scheduling policy to SCHED_RR
    pthread_setschedparam(pthread_self(), SCHED_RR, &param);

    // Record start time
    struct timespec start, stop; 
    if (clock_gettime(CLOCK_MONOTONIC, &start) == -1) {
        printf("Error occurred with clock_gettime");
    }

    // Perform counting operation
    long long int x;
    for (x = 1; x <= 100000000; x++) { 
    }

    printf("B = %lld\n", x);

    // Record stop time
    if (clock_gettime(CLOCK_MONOTONIC, &stop) == -1) {
        printf("Error occurred with clock_gettime");
    }

    // Calculate elapsed time
    double timeTaken = (stop.tv_sec - start.tv_sec) + 
                       (double)(stop.tv_nsec - start.tv_nsec) / (double)value;
    printf("B time = %lf\n", timeTaken);

    // Log the time to a file
    FILE *fp = fopen("b.txt", "a");
    char buf[1024];
    sprintf(buf, "%lf ", timeTaken);
    fputs(buf, fp);
    fclose(fp);

    return NULL;
}

// Function to perform counting with SCHED_FIFO scheduling policy
void *countC(void *arg) {
    // Extract priority argument
    int* priority = (int*) arg;
    struct sched_param param;
    param.sched_priority = (int)priority[1];

    // Set scheduling policy to SCHED_FIFO
    pthread_setschedparam(pthread_self(), SCHED_FIFO, &param);

    // Record start time
    struct timespec start, stop; 
    if (clock_gettime(CLOCK_MONOTONIC, &start) == -1) {
        printf("Error occurred with clock_gettime");
    }

    // Perform counting operation
    long long int x;
    for (x = 1; x <= 100000000; x++) { 
    }

    printf("C = %lld\n", x);

    // Record stop time
    if (clock_gettime(CLOCK_MONOTONIC, &stop) == -1) {
        printf("Error occurred with clock_gettime");
    }

    // Calculate elapsed time
    double timeTaken = (stop.tv_sec - start.tv_sec) + 
                       (double)(stop.tv_nsec - start.tv_nsec) / (double)value;
    printf("C time = %lf\n", timeTaken);

    // Log the time to a file
    FILE *fp = fopen("c.txt", "a");
    char buf[1024];
    sprintf(buf, "%lf ", timeTaken);
    fputs(buf, fp);
    fclose(fp);

    return NULL;
}

int main() {
    // Declare thread identifiers
    pthread_t thrA, thrB, thrC;
    int args[2]; // Array to store priorities for threads

    // Loop to create and join threads 10 times
    for (int i = 0; i < 10; i++) {
        // Assign priorities dynamically
        args[0] = 0 + 2 * i;
        args[1] = 1 + 10 * i;

        // Create threads for each scheduling policy
        pthread_create(&thrA, NULL, &countA, args);
        pthread_create(&thrB, NULL, &countB, args);
        pthread_create(&thrC, NULL, &countC, args);

        // Wait for threads to complete
        pthread_join(thrA, NULL);
        pthread_join(thrB, NULL);
        pthread_join(thrC, NULL);
    }

    return 0;
}

