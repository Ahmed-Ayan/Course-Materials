#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <assert.h>

const int SIZE_OF_HEADER = 3;
const int SIZE_OF_RESEARCH_AREA_HEADER = 3;

const int NUM_RESEARCH_AREAS_IDX = 0;
const int RESEARCH_AREAS_INFO_SLOT_OFFSET_INDEX = 1;
const int SHSTRNDX_INDEX = 2;

const int NAME_OFFSET_INDEX = 0;
const int NUM_SUMMARIES_INDEX = 1;
const int SUMMARY_OFFSET_INDEX = 2;

typedef struct {
    size_t nameOffset;
    size_t numSummaries;
    size_t summaryOffset;
} ResearchAreaHeader;

typedef struct {
    int numResearchAreas;
    int researchAreasInfoSlotOffset;
    int shstrndx;
} Header;

int main(int argc, char **argv){

    if (argc != 2){
        printf("usage: %s text_file\n",argv[0]);
        return 1;
    }

    int fd = open(argv[1], O_RDONLY);
    if (fd < 0){
        perror("couln't open text_file");
        exit(1);
    }

    struct stat st;
    fstat(fd, &st);
    size_t fsize = st.st_size;

    char *buff = malloc(fsize);
    assert(buff);

    ssize_t n = read(fd, buff, fsize);
    assert(n == (ssize_t)fsize);
    close(fd);

    char *ptr = buff;
    size_t remaining = fsize;

    char *map[100];
    int no_of_lines = 0;

    while (remaining > 0) {
        char *newline = memchr(ptr, '\n', remaining);
        size_t len;
        if (newline) {
            len = newline - ptr;
        } else {
            len = remaining;
        }

        map[no_of_lines] = malloc(len + 1);
        memcpy(map[no_of_lines], ptr, len);
        map[no_of_lines][len] = '\0';
        no_of_lines++;

        if (!newline) break;

        size_t consumed = len + 1;
        remaining -= consumed;
        ptr = newline + 1;
    }

    free(buff);

    Header header;

    header.numResearchAreas = atoi(map[NUM_RESEARCH_AREAS_IDX]);
    header.researchAreasInfoSlotOffset = atoi(map[RESEARCH_AREAS_INFO_SLOT_OFFSET_INDEX]);
    header.shstrndx = atoi(map[SHSTRNDX_INDEX]);

    int shstrndxSummaryOffset = atoi(map[header.researchAreasInfoSlotOffset + SIZE_OF_RESEARCH_AREA_HEADER * header.shstrndx + SUMMARY_OFFSET_INDEX]);

    for (int idx = 0; idx < header.numResearchAreas; idx++){
        int start = header.researchAreasInfoSlotOffset + idx * SIZE_OF_RESEARCH_AREA_HEADER;
        ResearchAreaHeader researchAreaHeader;
        researchAreaHeader.nameOffset = (size_t)atoi(map[start + NAME_OFFSET_INDEX]);
        researchAreaHeader.numSummaries = (size_t)atoi(map[start + NUM_SUMMARIES_INDEX]);
        researchAreaHeader.summaryOffset = (size_t)atoi(map[start + SUMMARY_OFFSET_INDEX]);

        printf("Research Area: %s\n", map[shstrndxSummaryOffset + researchAreaHeader.nameOffset]);

        for (size_t num = 0; num < researchAreaHeader.numSummaries; num++){
            printf("  %s\n", map[researchAreaHeader.summaryOffset + num]);
        }
        printf("\n");
    }

    for (int idx = 0; idx < no_of_lines; idx++){
        free(map[idx]);
    }

    close(fd);

  return 0;
}
