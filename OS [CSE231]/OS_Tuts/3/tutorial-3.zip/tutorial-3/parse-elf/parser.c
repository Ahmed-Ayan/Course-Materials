#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <elf.h>

int main(int argc, char **argv){

    if (argc != 2){
        printf("usage: %s binary_file\n", argv[0]);
        return 1;
    }

    int fd = open(argv[1], O_RDONLY);
    if (fd < 0){
        perror("couldn't open file");
        exit(1);
    }

    printf("File Descriptor: %d\n\n",fd);

    Elf32_Ehdr ehdr; // declares a variable ehdr of type Elf32_Ehdr, which is a structure defined in elf.h to represent the ELF header of a 32-bit ELF file

    if (read(fd, &ehdr, sizeof(ehdr)) != sizeof(ehdr)){ // reads the ELF header from the file into the ehdr struct buffer
        perror("ehdr is faulty");
        exit(1);
    }

    off_t e_shoff = ehdr.e_shoff; // the offset of the section header table from the beginning of the file
    size_t e_shentsize = ehdr.e_shentsize; // the size of each section header entry
    uint16_t e_shstrndx = ehdr.e_shstrndx; // the index of the section header that contains the section name string table

    off_t shstrtab_offset = e_shoff + e_shstrndx * e_shentsize; // the offset of the section header for the section name string table
    lseek(fd, shstrtab_offset, SEEK_SET); // moves the file descriptor fd to the position of the section header for the section name string table

    Elf32_Shdr shstrtab_hdr; // declares a variable shstrtab_hdr of type Elf32_Shdr, which represents a section header in the ELF file
    if (read(fd, &shstrtab_hdr, sizeof(shstrtab_hdr)) != sizeof(shstrtab_hdr)){ // reads the section header for the section name string table into shstrtab_hdr
        printf("Error");
        exit(1);
    }

    off_t shstrtab_content_offset = shstrtab_hdr.sh_offset; // the offset where the section name string table starts in the file
    size_t shstrtab_content_size = shstrtab_hdr.sh_size; // the size of the section name string table


    char *shstrtab = malloc(shstrtab_content_size); // allocates memory to hold the entire section name string table
    if (shstrtab == NULL){
        printf("Error");
        exit(1);
    }

    lseek(fd, shstrtab_content_offset, SEEK_SET); // moves the file descriptor to the beginning of the section name string table
    if (read(fd, shstrtab, shstrtab_content_size) != shstrtab_content_size) { // reads the entire section name string table into the allocated memory
        printf("Error");
        exit(1);
    }

    lseek(fd, e_shoff, SEEK_SET); // moves the file descriptor back to the start of the section header table

    for (int i = 0; i < ehdr.e_shnum; i++){ // loops over all section headers in the ELF file (ehdr.e_shnum gives the total number of sections)
        Elf32_Shdr shdr; // declares a variable shdr to hold each section header as it is read from the file
        if (read(fd, &shdr, sizeof(shdr)) != sizeof(shdr)) { // reads the next section header into shdr
            printf("Error");
            exit(1);
        }
        const char *section_name = shstrtab + shdr.sh_name; // retrieves the name of the section by using the sh_name field of the section header, which is an offset into the section name string table
        printf("Section %d: %s\n", i, section_name);
    }

    return 0;

}