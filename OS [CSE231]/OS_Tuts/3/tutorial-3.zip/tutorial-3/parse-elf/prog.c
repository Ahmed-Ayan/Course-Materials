#include <stdio.h>

int arr[10];

int main(){

    int a = 4477;

    char s[2] = "os";

    printf("Hello World");

    return 0;

}
