#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#define SIZE 4

int main() {
    int A[SIZE][SIZE] = {
        {1, 0, 1, 1},
        {0, 1, 0, 1},
        {1, 1, 0, 0},
        {0, 0, 1, 1}
    };

    int B[SIZE][SIZE] = {
        {0, 1, 1, 0},
        {1, 0, 1, 1},
        {0, 1, 0, 1},
        {1, 1, 1, 0}
    };

    int C[SIZE][SIZE] = {0};
    int sum = 0; // sum of all elements in C

    printf("Parent before fork, C is all zeros\n");

    for (int r = 0; r < SIZE; r++) {
        pid_t pid = fork();
        if (pid == 0) { // child
            int local_sum = 0;
            for (int j = 0; j < SIZE; j++) {
                int val = 0;
                for (int k = 0; k < SIZE; k++)
                    val += A[r][k] * B[k][j];
                C[r][j] = val;
                local_sum += val;
            }
            printf("Child computed row %d: ", r);
            for (int i = 0; i < SIZE; i++) {
                printf("%d ", C[r][i]);
            }
            printf("\n");
            exit(local_sum & 0xFF); // send sum via exit (only works for small ints!)
        }
    }

    // Parent collects child results
    for (int i = 0; i < SIZE; i++) {
        int status;
        wait(&status);
        if (WIFEXITED(status)) {
            sum += WEXITSTATUS(status);
        }
    }

    // Parent's C is unchanged due to Copy-on-Write
    printf("Parent after children finish, C is still:\n");
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            printf("%d ", C[i][j]);
        }
        printf("\n");
    }
    printf("\n");

    printf("Final sum of all C elements collected from children = %d\n", sum);
    return 0;
}
