#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <semaphore.h>

#define SHM_NAME "/my_shm"
#define SIZE 4

typedef struct {
    int A[SIZE][SIZE];
    int B[SIZE][SIZE];
    int C[SIZE][SIZE];
    int sum;
    sem_t lock;
} shm_t;

int main() {
    // Create shared memory
    int shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    ftruncate(shm_fd, sizeof(shm_t));
    shm_t *shm = mmap(NULL, sizeof(shm_t), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);

    // Initialize matrices
    int A[SIZE][SIZE] = {
        {1, 0, 1, 1},
        {0, 1, 0, 1},
        {1, 1, 0, 0},
        {0, 0, 1, 1}
    };

    int B[SIZE][SIZE] = {
        {0, 1, 1, 0},
        {1, 0, 1, 1},
        {0, 1, 0, 1},
        {1, 1, 1, 0}
    };
    for (int i = 0; i < SIZE; i++)
        for (int j = 0; j < SIZE; j++) {
            shm->A[i][j] = A[i][j];
            shm->B[i][j] = B[i][j];
            shm->C[i][j] = 0;
        }
    shm->sum = 0;
    sem_init(&shm->lock, 1, 1); // shared semaphore

    // Fork children
    for (int r = 0; r < SIZE; r++) {
        if (fork() == 0) {
            int local_sum = 0;
            for (int j = 0; j < SIZE; j++) {
                int val = 0;
                for (int k = 0; k < SIZE; k++)
                    val += shm->A[r][k] * shm->B[k][j];
                shm->C[r][j] = val;
                local_sum += val;
            }
            sem_wait(&shm->lock);
            shm->sum += local_sum;
            sem_post(&shm->lock);
            exit(0);
        }
    }

    for (int i = 0; i < SIZE; i++) wait(NULL);

    printf("Final matrix C:\n");
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            printf("%d ", shm->C[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    printf("Final sum = %d (correct due to semaphore!)\n", shm->sum);

    sem_destroy(&shm->lock);
    munmap(shm, sizeof(shm_t));
    shm_unlink(SHM_NAME);
    return 0;
}
