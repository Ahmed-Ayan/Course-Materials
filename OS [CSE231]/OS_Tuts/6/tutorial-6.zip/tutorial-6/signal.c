#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

// Custom signal handler
static void my_handler(int signum) {
    static int counter = 0;  
    if (signum == SIGINT) {
        char buff1[23] = "\nCaught SIGINT signal\n";
        write(STDOUT_FILENO, buff1, 23);
        if (counter++ == 1) {  
            char buff2[20] = "Cannot handle more\n";
            write(STDOUT_FILENO, buff2, 20);
            exit(0);
        }
    } 
}

int main() {
    struct sigaction sig;
    memset(&sig, 0, sizeof(sig));  
    sig.sa_handler = my_handler;   

    
    sigaction(SIGINT, &sig, NULL);   

    int n;
    while (1) {
        printf("Input a number: ");
        scanf("%d", &n);
        if (fork() == 0) {  // Child process
            printf("Child: Calculating Fibonacci(%d)...\n", n);
            exit(0);  // Terminate child process
        } else {
            wait(NULL);  // Parent waits for child to finish
        }
    }

    return 0;
}
