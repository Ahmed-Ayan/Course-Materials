#include<stdio.h>
#include "lib.h"
void hello_word(){
    printf("hello world\n");
}