#include <stdio.h>
#include "lib.h"
int main(){
    hello_word();
}