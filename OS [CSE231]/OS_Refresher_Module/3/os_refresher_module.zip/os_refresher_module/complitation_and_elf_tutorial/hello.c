#include <stdio.h>
int main(){
	printf("%s\n", "Hello Operating Systems");
	return 0;
}
